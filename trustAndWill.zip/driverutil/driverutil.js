import "chromedriver";
import "geckodriver";
import "iedriver";
import "edgedriver";
import { Builder } from "selenium-webdriver";

export default function getDriver() {
    var browser = process.env.BROWSER;
    var browsername = browser == undefined ? 'chrome' : browser;
    var driver;
    switch (browsername.toUpperCase()) {
        case 'FIREFOX':
            driver = new Builder().forBrowser('firefox').build();
            break;
        case 'CHROME':
            driver = new Builder().forBrowser('chrome').build();
            break;
        case 'IE':
            driver = new Builder().forBrowser('internet explorer').build();
            break;
        case 'EDGE':
            driver = new Builder().forBrowser('MicrosoftEdge').build();
            break;

        default:
            driver = new Builder().forBrowser('chrome').build();
    }
    global.driver = driver;
    return driver;
};


import { By, until, Key } from "selenium-webdriver";

class homepage {

    url = "https://trustandwill.com/";

    // Locators
    getStarted = By.xpath("(//a[@href='/get-started'])[2]");
    getStarted1 = By.xpath("(//a[normalize-space(text())='Get Started'])[3]");
    startMyWill  = By.xpath("//a[normalize-space(text())='Start My Will']");
    Emailusername = By.xpath("//input[@id='signin-email']");
    
    

    //Methods
    async waitUntilVisible() {
        await driver.wait(until.elementLocated(this.getStarted));
    };
    async navigate() {
        await driver.manage().window().maximize()
        await driver.navigate().to(this.url);
        await this.waitUntilVisible();
    };
    async EnterUsername(text) {
        await driver.findElement(this.Emailusername).sendKeys(text + Key.ENTER);
    }
    async clickOnGetStarted() {
       await driver.findElement(this.getStarted).click();
       await driver.wait(until.elementLocated(this.getStarted1))
    }

    async clickOnGetStarted1() {
        await driver.findElement(this.getStarted1).click();
        await driver.wait(until.elementLocated(this.startMyWill))
     }
    async clickOnStartMyWill() {
        await driver.findElement(this.startMyWill).click();
        await driver.wait(until.elementLocated(this.Emailusername))
     }
};

module.exports = homepage;

import homepage from '../pages/homepage';
import { assert, expect } from 'chai';
import getDriver from '../driverutil/driverutil';
require("mocha-allure-reporter");
{
    describe, before, after, it
}
var data = require("../testData/data.json")
describe('Trust & Will', function () {
    let driver;
    let homePage;
    this.timeout(50000);

    before(async () => {
        driver = await getDriver();
        homePage = new homepage();
        
    });

    it('Start My Will', async function () {
        await homePage.navigate();
        await homePage.waitUntilVisible();
        await homePage.clickOnGetStarted();
        expect(await driver.getTitle()).to.equal(data.HomePageTitle);
    });

    after(() => driver.quit());
});